const User = require('../model/user');

class UserRepository{
    async createUser(user){
        return await User.create(user);
    }

    async findAll(){
        return await User.findAll();
    }

    async findByUsername(username){
        return await User.FindOne({where: {username}})
    }
}

module.exports = new UserRepository();